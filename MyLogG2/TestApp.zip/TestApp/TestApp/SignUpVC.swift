//
//  SignUpVC.swift
//  TestApp
//
//  Created by Dhruv Singh on 17/02/17.
//  Copyright © 2017 Dhruv Singh. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {

    //MARK: IBOUTLET
    
    @IBOutlet weak var textFieldFirstName: UITextField!
    
    @IBOutlet weak var textFieldLastName: UITextField!
    
    @IBOutlet weak var textFieldEmail: UITextField!
    
    @IBOutlet weak var textFieldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - ACTIONS
    
    @IBAction func btnActionSignUp(_ sender: Any) {
        if textFieldFirstName.text!.trimmingCharacters(in: .whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Enter First Name")
            
        }else if textFieldLastName.text!.trimmingCharacters(in: .whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Enter Last Name")
            
        }else if textFieldEmail.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email")
        }
        else if proxy.sharedProxy().isValidEmail(textFieldEmail.text!) == false
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email.")
        }
        else if textFieldPassword.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
        }
        else
        {
            
    let arrUsers = DBManager.sharedDatabase().getUsers("SELECT * FROM FlowData order by id ASC")
            if arrUsers.count > 0 {
                let modalObject = arrUsers.lastObject as! UsersModal
                let enteriesQuery = NSString(format: "INSERT INTO 'flowUsers' VALUES (%ld,'%@','%@','%@','%@')",modalObject.id+1, textFieldFirstName.text!,textFieldLastName.text!,textFieldEmail.text!,textFieldPassword.text!)
                DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                
            }else{
                let enteriesQuery = NSString(format: "INSERT INTO 'flowUsers' VALUES (%ld,'%@','%@','%@','%@')", 1,textFieldFirstName.text!,textFieldLastName.text!,textFieldEmail.text!,textFieldPassword.text!)
                DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                
                self.performSegue(withIdentifier: "signUpToHome", sender: self)
            }
        }

        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
