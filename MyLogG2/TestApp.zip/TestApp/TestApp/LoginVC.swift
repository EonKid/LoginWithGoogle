//
//  LoginVC.swift
//  TestApp
//
//  Created by Dhruv Singh on 17/02/17.
//  Copyright © 2017 Dhruv Singh. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    //MARK: - IBOULET
    
    @IBOutlet weak var txtFieldEmail: UITextField!
    
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: - ACTIONS
    
    @IBAction func btnActionSignIn(_ sender: Any) {
        self.view.endEditing(true)
        
        if txtFieldEmail.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email")
        }
        else if proxy.sharedProxy().isValidEmail(txtFieldEmail.text!) == false
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email.")
        }
        else if txtFieldPassword.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
        }
        else
        {
        var isUserFound = Bool()
        let arrUsers = DBManager.sharedDatabase().getUsers("SELECT * FROM 'flowUsers' order by id ASC")
            for i in 0 ..< arrUsers.count{
                let userModal = arrUsers[i] as! UsersModal
                debugPrint("user email \(userModal.email) pwd: \(userModal.password)")
                if userModal.email == txtFieldEmail.text! && userModal.password == txtFieldPassword.text! {
                    isUserFound = true
                    self.performSegue(withIdentifier: "signInToHome", sender: self)
                    break
                }
            }
            
            if isUserFound == false{
                proxy.sharedProxy().displayStatusCodeAlert("User does not exist!")
            }
            
           
        }

        
    }
    
    
    @IBAction func btnActionCreateAccount(_ sender: Any) {
        
       self.performSegue(withIdentifier: "signInToSignUp", sender: self)
    }
    
    override func performSegue(withIdentifier identifier: String, sender: Any?) {
         super.performSegue(withIdentifier: identifier, sender: self)
    }
    

    
}
