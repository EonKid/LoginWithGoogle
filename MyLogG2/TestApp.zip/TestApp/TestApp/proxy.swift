//
//  proxy.swift
//  Flyzone
//
//  Created by Toxsl on 24/12/16.
//  Copyright © 2015 ToXSL Technologies Pvt. Ltd. All rights reserved.
//

import UIKit
import PKHUD
import MapKit
import Darwin

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

var KAppDelegate = UIApplication.shared.delegate as! AppDelegate
let willRegisterApp = true
var shareInstance:proxy = proxy()
// MARK: - Additional Headers
let  KMode = "debug"
let  KAppName = "TestApp"
let  KVersion =  "1.0"
let  kModel = UIDevice.current.model
let  kSystemVersion = UIDevice.current.systemVersion


var KServerUrl = "35.154.75.20:9090/test/ios"

// MARK: - USER DEFAULTS
let kEmail = "email"
let kPassword = "password"
var appColor = UIColor(red: 78/255, green: 88/255, blue: 103/255, alpha: 1)

// MARK: - Protocol

@objc protocol WebServiceDelegate
{
    func retryMethod(_ paramsDic:Dictionary<String,AnyObject>, withServiceUrl:NSString, error:NSError?)
}

var delegateObject: WebServiceDelegate?
class proxy: NSObject {
    
    // MARK: - Class Variables
    
    class func sharedProxy() -> proxy {
        shareInstance = proxy()
        return shareInstance
    }
    
    func checkStringIfNull(_ content: String) -> String {
        if ((content == "null")) || ((content == "(null)")) || ((content == "<null>")) || ((content == "nil")) || ((content == "")) || ((content == "<nil>")) || (content.characters.count == 0){
            return ""
        }
        else {
            return content
        }
    }
    
    
    func getRandomColor() -> UIColor{
        //Generate between 0 to 1
        let red:CGFloat = CGFloat(drand48())
        let green:CGFloat = CGFloat(drand48())
        let blue:CGFloat = CGFloat(drand48())
        
        return UIColor(red:red, green: green, blue: blue, alpha: 0.40)
    }
    
    func authNil () -> String
    {
        if(UserDefaults.standard.object(forKey: "auth_code") == nil){
            return ""
        }
        else{
            return String(describing: UserDefaults.standard.object(forKey: "auth_code") as AnyObject)
        }
    }
    
    
    
    
    //MARK:- Show alert
    
    func showAlert(_ title:String, message:String, buttonAction:String)  {
        let alert = UIAlertView()
        alert.title = title
        alert.message = message
        alert.addButton(withTitle: buttonAction)
        alert.show()
    }

       // MARK:- CHECK CONTAINS STRING
    func containsOnlyLetters(_ input: String) -> Bool {
        for chr in input.characters {
            if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") ) {
                return false
            }
        }
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789")
        if input.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            return false
        }
        return true
    }
    
    //MARK:- DATES FUNCTIONS
    func getTimeString(_ strDate:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"//this your string date format
        let date = dateFormatter.date(from: strDate)
        dateFormatter.dateFormat = "dd.MM.yyyy"///this is you want to convert format
        let timeStamp = dateFormatter.string(from: date!)
        return timeStamp
    }
    
    
  

    // MARK: - Error Handling
    func stautsHandler(_ url:String, parameter:Dictionary<String,AnyObject>? = nil, response:HTTPURLResponse?, data:Data?, error:NSError?)
    {
        
        if  response?.statusCode == 400
        {
            displayStatusCodeAlert("bad url")
        }
        else if response?.statusCode == 401
        {
            displayStatusCodeAlert("unauthorized")
        }
        else if response?.statusCode == 404
        {
            displayStatusCodeAlert("file not found")
        }
        else if response?.statusCode ==  500
        {
            let myHTMLString = NSString(data: data!, encoding:String.Encoding.utf8.rawValue)
            HtmlDisplayStatusAlert(myHTMLString as! String)
            debugPrint("HTML string : \(myHTMLString as! String)")
            
        }
        else if response?.statusCode == 408
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
        else if error?.code == -1001
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
        else if error?.code == -1009
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
    }
    
    func displayStatusCodeAlert(_ userMessage: String)
    {
        UIView.hr_setToastThemeColor(appColor)
        KAppDelegate.window!.makeToast(message: userMessage)
    }
    
    //MARK: - Alert Native Dismiss
    func showAlert(_ title: String,message: String)  {
         var alertVc = UIAlertController()
        alertVc = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        UIApplication.shared.keyWindow?.rootViewController?.present(alertVc, animated: true, completion: {
            let delay = 2.0 * Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                alertVc.dismiss(animated: true, completion: nil)
            }
        })
    }
    
    
    
    // Html Display Alert
    
    func HtmlDisplayStatusAlert(_ userMessage: String)
    {
        var codeErrorAlert = UIAlertController()
        DispatchQueue.main.async
        {
            KAppDelegate.hideActivityIndicator()
            codeErrorAlert = UIAlertController(title: "", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
            codeErrorAlert.addAction(UIAlertAction(title: "Show", style: .default, handler: { action in
            KAppDelegate.hideActivityIndicator()
            }))
            UIApplication.shared.keyWindow?.rootViewController?.present(codeErrorAlert, animated: true, completion: nil)
        }
    }
    

    //#MARK: - Email Validations
    
    func isValidEmail(_ testStr:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let range = testStr.range(of: emailRegEx, options:.regularExpression)
        let result = range != nil ? true : false
        return result
    }
   
    func openSettingApp()
    {
        var settingAlert = UIAlertController()
        DispatchQueue.main.async
            {
                KAppDelegate.hideActivityIndicator()
                settingAlert = UIAlertController(title: "Connection Problem", message: "Please check your internet connection", preferredStyle: UIAlertControllerStyle.alert)
                let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
                settingAlert.addAction(okAction)
                
                let openSetting = UIAlertAction(title:"Setting", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                  UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
                })
                settingAlert.addAction(openSetting)
                UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
                
        }
    }
    
    
    func RequestTimeOutAlertMessage(_ alrtMessage:NSString, Url:String, Parameter:Dictionary<String, AnyObject>? = nil, Response: HTTPURLResponse? , data: Data? , Error:NSError?)
     {
        KAppDelegate.hideActivityIndicator()
        
        if (Parameter?.count) > 0
        {
            
            var timeOutAlert = UIAlertController()
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title:"Cancel", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
            })
            
            timeOutAlert.addAction(retryAction)
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
        }
        else
        {
            
            var timeOutAlert = UIAlertController()
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                if(Parameter != nil){
                    delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
                }
                else{
                    delegateObject?.retryMethod([:], withServiceUrl:Url as NSString, error:Error)
                }
                
            })
            
            timeOutAlert.addAction(retryAction)
            
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
            
        }
    }
    
  }
