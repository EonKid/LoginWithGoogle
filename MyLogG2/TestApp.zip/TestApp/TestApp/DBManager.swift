//
//  DBManager.swift
//  FlyZone
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Foundation

var shareDBInstance:DBManager = DBManager()

class DBManager: NSObject {
   
    var dataBaseConnection: OpaquePointer? = nil
    class func sharedDatabase() -> DBManager {
            shareDBInstance = DBManager()
        return shareDBInstance
    }
    
    class func createEditableCopyOfDatabaseIfNeeded() {
        let fileManager: FileManager = FileManager()
        var paths: [String] = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory: String = paths[0]
        let writableDBPath: String = documentDirectory.stringByAppendingPathComponent("FlowData.sqlite")
        var success: Bool
        success = fileManager.fileExists(atPath: writableDBPath)
        if success {
            NSLog("Alredy exist")
            return
        }
        
        let defaultDBPath: String = (Bundle.main.resourcePath!.stringByAppendingPathComponent("FlowData.sqlite"))
        do {
            try fileManager.copyItem(atPath: defaultDBPath, toPath: writableDBPath)
        } catch let error as NSError{
            NSLog("failed to create the databse at path with error \(error.localizedDescription)")
        }
    }
    
    func openDatabaseConnection() {
        var paths: [String] = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory: String = paths[0]
        let path: String = documentDirectory.stringByAppendingPathComponent("FlowData.sqlite")
        if sqlite3_open(path.cString(using: String.Encoding.utf8)!, &dataBaseConnection) == SQLITE_OK {
            NSLog("database successfully open")
        }
        else{
            NSLog("error in opening database")
        }
    }
    
    func closeDatabaseConnection() {
        sqlite3_close(dataBaseConnection)
        NSLog("Database succeessfully closed")
    }
    
    func executeQuery(_ query: String) {
        self.openDatabaseConnection()
        let sql:[CChar] = query.cString(using: String.Encoding.utf8)!
        var statement: OpaquePointer? = nil
        if sqlite3_prepare_v2(dataBaseConnection, sql, -1, &statement, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(dataBaseConnection))
            NSLog("Error preparing statment %@", errmsg)
        } else {
            sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
        self.closeDatabaseConnection()
    }
    
    func getUsers(_ query: String) -> NSMutableArray {
        self.openDatabaseConnection()
       let arrUsers = NSMutableArray()
        let sql:[CChar] = query.cString(using: String.Encoding.utf8)!
        var statement: OpaquePointer? = nil
        if sqlite3_prepare_v2(dataBaseConnection, sql, -1, &statement, nil) != SQLITE_OK {
            NSLog("Error preparing statment", sqlite3_errmsg(dataBaseConnection))
        } else {
            while sqlite3_step(statement) == SQLITE_ROW {
                let userModal = UsersModal()
               //Event id
                let rowId = sqlite3_column_int(statement, 0)
                userModal.id = rowId
               
                //First Name
                let firstName = sqlite3_column_text(statement, 1)
                if firstName != nil {
                    let firstNameString = String(cString: firstName!)
                    userModal.first_name = firstNameString
                } else {
                    userModal.first_name = ""
                }
                
                //Last Name
                let lastName = sqlite3_column_text(statement, 2)
                if firstName != nil {
                    let lastNameString = String(cString: lastName!)
                    userModal.last_name = lastNameString
                } else {
                    userModal.last_name = ""
                }
                
                //Email
                let email = sqlite3_column_text(statement, 3)
                if firstName != nil {
                    let emailString = String(cString: email!)
                    userModal.email = emailString
                } else {
                    userModal.email = ""
                }
                
                //Password
                let password = sqlite3_column_text(statement, 4)
                if firstName != nil {
                    let passwordString = String(cString: password!)
                    userModal.password = passwordString
                } else {
                    userModal.password = ""
                }
              
                arrUsers.add(userModal)
            }

        }
        sqlite3_finalize(statement)
        self.closeDatabaseConnection()
        return arrUsers
    }
}
