//
//  RestaurantsVC.swift
//  TestApp
//
//  Created by Dhruv Singh on 17/02/17.
//  Copyright © 2017 Dhruv Singh. All rights reserved.
//

import UIKit

class RestaurantsVC: UIViewController ,UITableViewDelegate ,UITableViewDataSource{

    //MARK: - IBOUTLET
    
    @IBOutlet weak var tvRestaurants: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    self.getAllRestaurants(strURL: KServerUrl)
        
    }

    //MARK: WEBSERVICE RESPONSE
    
    func getAllRestaurants(strURL:String) {
        
        WebServiceRequest.getData(url: strURL, success: { (dictRespose) in
            
        }) { (error) in
            
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    //MARK: - UITABLEVIEWDELEGATE AND DATASOURCE
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
    
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "restaurantCell", for: indexPath)
        return cell
    }
    

    

    //MARK: - ACTIONS
    
    @IBAction func btnActionLogout(_ sender: Any) {
        
        self.navigationController?.popToRootViewController(animated: false)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
