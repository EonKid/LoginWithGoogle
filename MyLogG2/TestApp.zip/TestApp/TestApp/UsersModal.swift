//
//  UsersModal.swift
//  TestApp
//
//  Created by Dhruv Singh on 17/02/17.
//  Copyright © 2017 Dhruv Singh. All rights reserved.
//

import UIKit

class UsersModal: NSObject {
    
    var id = Int32()
    var first_name = String()
    var last_name  = String()
    var email = String()
    var password = String()
   
}
